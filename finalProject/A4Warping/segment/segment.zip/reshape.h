//
// Created by Chen Sihang on 2018/12/21.
//

#ifndef SEGMENT_RESHAPE_H
#define SEGMENT_RESHAPE_H
#include "public.h"

class reshape {
    reshape(CImg<unsigned char>&);
};


#endif //SEGMENT_RESHAPE_H
